# Ads Dashboard

A Google Ads-inspired dashboard starter built with Next.js.

## Run locally
1. Install Node.js 20+.
2. Run `npm install`
3. Copy `.env.example` to `.env.local`
4. Set `NEXT_PUBLIC_LOGIN_EMAIL` to the email you want to allow.
5. Run `npm run dev`
6. Open http://localhost:3000

## Important
The login in this starter is a UI/demo gate only. It does NOT securely authenticate a real password. For a real private website, connect Firebase Authentication, Auth.js, Clerk, Supabase Auth, or another proper authentication provider.

Never hard-code a Gmail password in JavaScript, HTML, GitHub, or Vercel source code.

## Deploy
Push the project to GitHub and import it into Vercel. Add environment variables in Vercel Project Settings.
