 "use client";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import {
  LayoutDashboard, Megaphone, BarChart3, Search, Users, Wallet,
  MapPin, Smartphone, FileText, Bell, Settings, LogOut, Menu,
  ChevronDown, ArrowUpRight, ArrowDownRight
} from "lucide-react";

const nav = [
  ["Overview", LayoutDashboard],
  ["Campaigns", Megaphone],
  ["Insights", BarChart3],
  ["Ad groups", Search],
  ["Keywords", Search],
  ["Ads", Megaphone],
  ["Audiences", Users],
  ["Billing & payments", Wallet],
  ["Locations", MapPin],
  ["Devices", Smartphone],
  ["Reports", FileText],
  ["Notifications", Bell],
  ["Settings", Settings]
];

export default function Dashboard() {
  const router = useRouter();
  const [ready,setReady] = useState(false);
  const [mobile,setMobile] = useState(false);

  useEffect(()=>{
    if (localStorage.getItem("ads_demo_session") !== "1") router.replace("/login");
    else setReady(true);
  },[router]);

  if (!ready) return <div className="loading">Loading…</div>;

  return <div className="dashboard">
    <aside className={mobile ? "sidebar open":"sidebar"}>
      <div className="side-brand">Ads<span>Dashboard</span></div>
      <div className="account"><div className="avatar">P</div><div><b>Prasenjit</b><small>Ads account</small></div><ChevronDown size={16}/></div>
      <nav>{nav.map(([label,Icon],i)=><button className={i===0?"active":""} key={label}><Icon size={18}/><span>{label}</span></button>)}</nav>
      <button className="logout" onClick={()=>{localStorage.removeItem("ads_demo_session");router.push("/login")}}><LogOut size={18}/> Sign out</button>
    </aside>

    <section className="main">
      <header className="topbar">
        <button className="menu" onClick={()=>setMobile(!mobile)}><Menu/></button>
        <div><b>Overview</b><div className="muted">Advertising account performance</div></div>
        <div className="top-actions"><span className="status-dot"/> Account active</div>
      </header>

      <div className="content">
        <div className="page-title"><div><h1>Overview</h1><p className="muted">Your account performance at a glance.</p></div><button className="date">Last 30 days <ChevronDown size={16}/></button></div>

        <div className="cards">
          <Metric title="Cost" value="$12,480.00" change="+8.4%" up/>
          <Metric title="Clicks" value="24,891" change="+12.1%" up/>
          <Metric title="Impressions" value="486,220" change="+5.8%" up/>
          <Metric title="Conversions" value="1,284" change="-2.4%" />
        </div>

        <div className="grid2">
          <section className="panel chart-panel"><div className="panel-head"><div><h2>Performance</h2><p className="muted">Spend and conversions</p></div><span className="pill">30 days</span></div><div className="fake-chart"><div className="bars">{[38,62,44,70,54,78,66,86,58,72,92,64].map((h,i)=><div key={i} className="bar" style={{height:h+"%"}} />)}</div><div className="axis"><span>Sep 5</span><span>Sep 15</span><span>Sep 25</span><span>Oct 4</span></div></div></section>
          <section className="panel"><div className="panel-head"><div><h2>Campaigns</h2><p className="muted">Top campaigns</p></div><button className="link-btn">View all</button></div><Campaign name="Search — Brand" clicks="8,420" cost="$3,240"/>
          <Campaign name="Performance Max" clicks="6,982" cost="$4,180"/><Campaign name="Display — Remarketing" clicks="4,210" cost="$1,920"/><Campaign name="Search — Generic" clicks="3,891" cost="$2,140"/></section>
        </div>

        <section className="panel table-panel"><div className="panel-head"><div><h2>Campaign performance</h2><p className="muted">Detailed campaign metrics</p></div><button className="primary small-btn">+ New campaign</button></div>
          <div className="table-wrap"><table><thead><tr><th>Campaign</th><th>Status</th><th>Impressions</th><th>Clicks</th><th>CTR</th><th>Cost</th><th>Conversions</th></tr></thead><tbody>
          {[
            ["Search — Brand","Active","92,420","8,420","9.11%","$3,240","412"],
            ["Performance Max","Active","148,220","6,982","4.71%","$4,180","386"],
            ["Display — Remarketing","Active","110,420","4,210","3.81%","$1,920","294"],
            ["Search — Generic","Paused","135,160","3,891","2.88%","$2,140","192"]
          ].map(r=><tr key={r[0]}><td><b>{r[0]}</b></td><td><span className={r[1]==="Active"?"active-badge":"paused-badge"}>{r[1]}</span></td>{r.slice(2).map(x=><td key={x}>{x}</td>)}</tr>)}
          </tbody></table></div>
        </section>
      </div>
    </section>
  </div>;
}

function Metric({title,value,change,up}) {return <div className="metric"><p>{title}</p><strong>{value}</strong><span className={up?"up":"down"}>{up?<ArrowUpRight size={15}/>:<ArrowDownRight size={15}/>} {change}</span><small>vs. previous period</small></div>}
function Campaign({name,clicks,cost}) {return <div className="campaign"><div className="campaign-icon"><Megaphone size={16}/></div><div><b>{name}</b><small>{clicks} clicks</small></div><strong>{cost}</strong></div>}