import "./globals.css";

export const metadata = {
  title: "Ads Dashboard",
  description: "Google Ads-inspired advertising dashboard"
};

export default function RootLayout({ children }) {
  return <html lang="en"><body>{children}</body></html>;
}