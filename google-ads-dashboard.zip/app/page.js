import Link from "next/link";
import { BarChart3, Megaphone, Wallet, Users, ArrowRight } from "lucide-react";

export default function Home() {
  return (
    <main className="landing">
      <div className="brand">Ads<span>Dashboard</span></div>
      <div className="hero">
        <div className="eyebrow">ADVERTISING MANAGEMENT</div>
        <h1>Manage your campaigns<br/>from one dashboard.</h1>
        <p>Track performance, budgets, audiences and campaigns in a clean advertising workspace.</p>
        <Link className="primary" href="/login">Sign in <ArrowRight size={18}/></Link>
      </div>
      <div className="feature-grid">
        <Feature icon={<BarChart3/>} title="Analytics" text="Monitor clicks, impressions and conversions."/>
        <Feature icon={<Megaphone/>} title="Campaigns" text="Organize and review advertising campaigns."/>
        <Feature icon={<Wallet/>} title="Budget" text="Keep track of spend and account balance."/>
        <Feature icon={<Users/>} title="Audiences" text="Review audience and targeting performance."/>
      </div>
    </main>
  );
}
function Feature({icon,title,text}) {
  return <div className="feature"><div className="icon">{icon}</div><h3>{title}</h3><p>{text}</p></div>;
}