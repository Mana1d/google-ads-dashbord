 "use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";

export default function Login() {
  const [email,setEmail] = useState("");
  const [password,setPassword] = useState("");
  const [error,setError] = useState("");
  const router = useRouter();

  function submit(e) {
    e.preventDefault();
    setError("");
    // DEMO ONLY: replace this with Firebase/Auth.js/server authentication.
    const allowed = process.env.NEXT_PUBLIC_LOGIN_EMAIL || "";
    if (allowed && email.toLowerCase() !== allowed.toLowerCase()) {
      setError("This account is not authorized.");
      return;
    }
    if (!email || !password) {
      setError("Enter your email and password.");
      return;
    }
    localStorage.setItem("ads_demo_session","1");
    router.push("/dashboard");
  }

  return <main className="auth">
    <div className="auth-card">
      <Link href="/" className="brand">Ads<span>Dashboard</span></Link>
      <h1>Sign in</h1>
      <p className="muted">Access your advertising dashboard.</p>
      <form onSubmit={submit}>
        <label>Email</label>
        <input type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="you@example.com" autoComplete="email"/>
        <label>Password</label>
        <input type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="••••••••" autoComplete="current-password"/>
        {error && <div className="error">{error}</div>}
        <button className="primary full">Sign in</button>
      </form>
      <p className="small">For production, connect this form to Firebase Auth, Auth.js, or another secure identity provider. Never store a password in frontend code.</p>
    </div>
  </main>;
}